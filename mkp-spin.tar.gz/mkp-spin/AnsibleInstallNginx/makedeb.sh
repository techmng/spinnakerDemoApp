sudo dpkg-deb --build deploy
#sudo dpkg -i deployableNginx.deb
sudo deb-s3 upload --bucket spin-log-bucket --access-key-id="AKIAIIKRBQNEMO7CXFFQ" --secret-access-key="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" --arch amd64 --codename xenial --preserve-versions false *.deb
